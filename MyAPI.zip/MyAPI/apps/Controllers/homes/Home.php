<?php

class Home {
    public function index() {
        echo "Selamat datang di halaman utama!";
    }

    public function about() {
        echo "Ini adalah halaman about.";
    }
}
