<?php

class Welcome {
    public function index() {
        echo "Selamat datang di halaman utama!";
    }

    public function about() {
        echo "Ini adalah halaman about.";
    }
}
